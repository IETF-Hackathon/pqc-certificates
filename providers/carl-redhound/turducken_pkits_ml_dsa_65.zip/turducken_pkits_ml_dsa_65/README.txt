Turducken PKITS, ML-DSA-65 (draft-davidben-lamps-turducken-certs-00)

The PKITS end entity certificates, recut as turducken certificates. Each outer certificate is a stock
PKITS RSA 2048 end entity certificate, reissued by its stock PKITS issuer with an alternate certificate,
issued by an ML-DSA-65 clone of the same PKITS CA, in its embedded SCT extension. The outer and
alternate certify the same RSA key and carry the same subject and serial number, so the stock CRLs
cover the outer certificates and the clone's CRLs cover the alternates. Every outer path should get
the stock PKITS verdict, and every alternate path the same verdict.

outer/       219 outer certificates, named as in PKITS; validate them with rsa_2048/
alternate/   219 alternates as issued, for reference; a relying party rebuilds each from its outer
             certificate. Validate them with ml_dsa_65/
pkcs12/      the end entity keys, the stock PKITS RSA 2048 files (password "password", 3DES and
             a SHA-1 MAC as published, so OpenSSL 3 needs -legacy)

rsa_2048/    stock PKITS, unaltered: ta/ (TrustAnchorRootCertificate), certs/ (the CA certificates,
             .crt, DER), crls/
ml_dsa_65/   the ML-DSA-65 clone of the PKITS CAs: ta/, certs/, crls/, and pkcs12/ with each CA's
             key three ways, as the seed (_seed), the expanded key (_expanded) or both (_both),
             password "password"

The clone CAs have their own names ("ML-DSA-65" appended to the most specific attribute, e.g.
CN=Good CA ML-DSA-65) and key identifiers, so no path crosses between the two hierarchies.
Signature defects, name constraints, policies and revocation are carried over from PKITS, and the
time of interest is PKITS's.

Not included: the DSA cases (InvalidDSASignatureTest6, ValidDSAParameterInheritanceTest5,
ValidDSASignaturesTest4) and Validpre2000UTCnotBeforeDateTest3. Outer and alternate validity is
encoded as UTCTime, so 4.2.4's GeneralizedTime notBefore is not preserved.

Code points: the draft's TBD values are placeholders here, 1.3.6.1.5.5.7.1.99 for
id-pe-outerCertificateBinding (TBD2) and 0xE000 for alternate_issuer_info (TBD3).
