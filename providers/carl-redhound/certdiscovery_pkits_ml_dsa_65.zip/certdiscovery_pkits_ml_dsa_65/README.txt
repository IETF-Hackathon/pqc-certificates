Certificate Discovery PKITS, ML-DSA-65 (draft-ietf-lamps-certdiscovery-06)

The PKITS end entity certificates, recut to reference a post-quantum counterpart. Each stock PKITS
RSA 2048 end entity certificate is reissued by its stock PKITS issuer with a subject information
access (SIA) extension appended. The extension holds one id-ad-certDiscovery access description
whose RelatedCertificateDescriptor references the certificate of the same name issued by an
ML-DSA-65 clone of the same PKITS CA. Nothing else about the certificate changes: subject, serial
number, validity, the other extensions and the PKITS defects are as published, so the stock CRLs
cover it and it gets the stock PKITS verdict.

Unlike a turducken alternate, a referenced certificate certifies its own key: each referenced
certificate has an ML-DSA-65 key of its own and the same subject and serial number as the
certificate referencing it. It carries the PKITS defects too, so it gets the same verdict under the
ML-DSA-65 clone.

Each end entity is provided two ways:

inclusion/   219 certificates whose descriptor includes the referenced certificate (byInclusion).
             Self-contained: nothing needs to be retrieved.
uri/         219 certificates whose descriptor names the referenced certificate by URI (byUri),
             with its signature algorithm (id-ml-dsa-65), public key algorithm (id-ml-dsa-65) and
             SHA-256 hash (certHash), all of which a relying party checks after retrieving it
             (Section 3.1.1). The URIs are
             https://downloads.redhoundsoftware.com/certdiscovery/pkits_ml_dsa_65/<name>.der
referenced/  219 referenced certificates, named as the end entities that reference them. These are
             the certificates inclusion/ embeds and uri/ names.
pkcs12/      the end entity keys: <name>.p12 is the stock PKITS RSA 2048 file for the certificates
             in inclusion/ and uri/ (password "password", 3DES and a SHA-1 MAC as published, so
             OpenSSL 3 needs -legacy), and <name>_seed.p12, <name>_expanded.p12 and <name>_both.p12
             hold the referenced certificate's ML-DSA-65 key as the seed, the expanded key or both
             (password "password")

rsa_2048/    stock PKITS, unaltered: ta/ (TrustAnchorRootCertificate), certs/ (the CA certificates,
             .crt, DER), crls/
ml_dsa_65/   the ML-DSA-65 clone of the PKITS CAs: ta/, certs/, crls/, and pkcs12/ with each CA's
             key three ways, as above

rsa_2048/ and ml_dsa_65/ are identical to the folders of the same names in
turducken_pkits_ml_dsa_65.zip, so the two sets can be used against one pair of hierarchies. The
clone CAs have their own names ("ML-DSA-65" appended to the most specific attribute, e.g.
CN=Good CA ML-DSA-65) and key identifiers, so no path crosses between the two hierarchies. The time
of interest is PKITS's.

Checking the set
================

Use the PKITS settings for each test as usual (the policy tests need their initial policy sets).
The certificates in inclusion/ and uri/ go with rsa_2048/, and the referenced certificates go with
ml_dsa_65/.

1. Validate each certificate in inclusion/ or uri/ with rsa_2048/ as the trust anchor, CA
   certificates and CRLs. Expect the stock PKITS verdict. The SIA extension is non-critical, so a
   relying party that does not know id-ad-certDiscovery gets the same answer.

2. Validate each certificate in referenced/ with ml_dsa_65/ as the trust anchor, CA certificates
   and CRLs. Expect the same verdict.

3. To exercise discovery, give a relying party that implements the draft a certificate from
   inclusion/ or uri/ and ml_dsa_65/ only. The certificate itself has no path, since its issuer is
   an RSA CA, and the referenced certificate, taken out of the descriptor or retrieved from its URI
   and checked against it, should be validated as its own target (Section 6) and get the PKITS
   verdict. For uri/, the relying party must be able to reach downloads.redhoundsoftware.com.

PKITS's own CA certificates in end entity position: eleven of the PKITS targets are CA
certificates (basicConstraints cA=TRUE), for example ValidpathLenConstraintTest8EE and
InvalidpathLenConstraintTest6EE. Their referenced certificates are CA certificates too. A CA
certificate's referenced certificates are other CA certificates to build paths with, not targets
of their own, so in step 3 a relying party may not validate them as targets. Step 2 covers them.

Not included: the DSA cases (InvalidDSASignatureTest6, ValidDSAParameterInheritanceTest5,
ValidDSASignaturesTest4) and Validpre2000UTCnotBeforeDateTest3, which the ML-DSA-65 clone does not
reproduce.

Code points: the draft's TBD values are placeholders here, in the arcs the draft assigns them to:
1.3.6.1.5.5.7.48.99 for id-ad-certDiscovery (TBD2) and 1.3.6.1.5.5.7.8.99 for
id-on-relatedCertificateDescriptor (TBD3). id-ad-certDiscoverySelfLocation is not used.
