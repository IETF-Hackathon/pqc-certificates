#!/bin/bash

# be sure to not add wrapped pubkeys:
unset DRAFT_MASSIMO_LAMPS_PQ_SIG_CERTIFICATES_00

gen() {
   mkdir $2 && cd $2
   # Root/TA:
   mkdir ta
   openssl req -outform der -x509 -new -newkey $1 -keyout ta/ta_priv.der -out ta/ta.der -nodes -subj "/CN=TA"
   # Intermediate CA:
   mkdir ca
   openssl req -outform der -new -newkey $1 -keyout ca/ca_priv.der -out ca/ca.csr -nodes -subj "/CN=CA"
   openssl x509 -outform der -req -in ca/ca.csr -out ca/ca.der -CA ta/ta.der -CAkey ta/ta_priv.der -CAcreateserial -days 365
   # End Entity cert:
   mkdir ee
   openssl req -outform der -new -newkey $1 -keyout ee/cert_priv.der -out ee/cert.csr -nodes -subj "/CN=EE"
   openssl x509 -outform der -req -in ee/cert.csr -out ee/cert.der -CA ca/ca.der -CAkey ca/ca_priv.der -CAcreateserial -days 365
   cd ..
}

gen dilithium2 1.3.6.1.4.1.2.267.7.4.4 
gen dilithium3 1.3.6.1.4.1.2.267.7.6.5
gen dilithium5 1.3.6.1.4.1.2.267.7.8.7
gen dilithium2_aes 1.3.6.1.4.1.2.267.11.4.4
gen dilithium3_aes 1.3.6.1.4.1.2.267.11.6.5
gen dilithium5_aes 1.3.6.1.4.1.2.267.11.8.7
gen falcon512 1.3.9999.3.1
gen falcon1024 1.3.9999.3.4
gen sphincssha256128frobust 1.3.9999.6.4.1
